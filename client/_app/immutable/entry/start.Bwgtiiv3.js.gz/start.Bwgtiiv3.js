import{a as t}from"../chunks/D52XMmf-.js";export{t as start};
